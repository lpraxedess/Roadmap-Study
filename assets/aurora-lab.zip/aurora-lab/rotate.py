"""Rotação local do bearer SCIM em duas fases; não imprime os valores."""
import argparse
import secrets
from pathlib import Path

root=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('action', choices=['prepare','activate'])
a=p.parse_args()
path=root/'.env'
cfg=dict(line.split('=',1) for line in path.read_text().splitlines() if '=' in line)
if a.action=='prepare':
    if 'SCIM_TOKEN_NEXT' in cfg:
        raise SystemExit('Já existe próxima credencial. Teste-a e só depois ative.')
    cfg['SCIM_TOKEN_NEXT']=secrets.token_urlsafe(32)
else:
    if 'SCIM_TOKEN_NEXT' not in cfg:
        raise SystemExit('Execute prepare e teste o consumidor antes de activate.')
    cfg['SCIM_TOKEN']=cfg.pop('SCIM_TOKEN_NEXT')
temporary=root/'.env.new'
temporary.write_text('\n'.join(k+'='+v for k,v in cfg.items())+'\n')
temporary.chmod(0o600)
temporary.replace(path)
print('Preparada: teste o consumidor com SCIM_TOKEN_NEXT.' if a.action=='prepare' else 'Ativada: novas execuções do consumidor leem SCIM_TOKEN; a anterior deve falhar.')
