"""Provisionador didático: RH -> SCIM e Keycloak, com prévia e reconciliação."""
import argparse
import csv
import json
import urllib.parse
import urllib.request
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENTERPRISE = 'urn:ietf:params:scim:schemas:extension:enterprise:2.0:User'
cfg = dict(line.split('=', 1) for line in (ROOT / '.env').read_text().splitlines() if '=' in line)

def request(url, method='GET', data=None, token=None, form=False):
    headers = {'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/scim+json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = urllib.parse.urlencode(data).encode() if form else json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(url, method=method, data=body, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as res:
        raw = res.read()
        return json.loads(raw) if raw else None

def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('csv_file')
    parser.add_argument('--apply', action='store_true', help='Sem essa opção: somente prévia')
    args = parser.parse_args()
    with open(args.csv_file, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    ids, names = set(), set()
    for row in rows:
        if not all(row.get(k) for k in ['employeeId', 'userName', 'displayName', 'department', 'status']):
            raise ValueError('CSV incompleto')
        if row['status'] not in ['active', 'inactive'] or row['department'] not in ['Financeiro', 'Jurídico', 'TI'] or row['employeeId'] in ids or row['userName'] in names:
            raise ValueError('Status, departamento ou identidade duplicada inválidos')
        ids.add(row['employeeId']); names.add(row['userName'])
    admin = None
    if args.apply:
        admin = request('http://localhost:8080/realms/master/protocol/openid-connect/token', 'POST', {'grant_type': 'password', 'client_id': 'admin-cli', 'username': 'admin', 'password': cfg['KC_ADMIN_PASSWORD']}, form=True)['access_token']
    for row in rows:
        print(('APLICAR' if args.apply else 'PRÉVIA'), row['employeeId'], row['department'], row['status'])
        if not args.apply:
            continue
        # Reconcile by immutable employee ID, never infer a different person from an email.
        users = request('http://localhost:8765/scim/v2/Users?' + urllib.parse.urlencode({'filter': 'externalId eq "' + row['employeeId'] + '"'}), token=cfg['SCIM_TOKEN'])['Resources']
        active = row['status'] == 'active'
        if users:
            current = users[0]
            if current['userName'] != row['userName']:
                raise ValueError('Mudança de userName requer plano de correlação; não criar outra identidade')
            request('http://localhost:8765/scim/v2/Users/' + current['id'], 'PATCH', {'schemas': ['urn:ietf:params:scim:api:messages:2.0:PatchOp'], 'Operations': [{'op': 'replace', 'path': 'active', 'value': active}, {'op': 'replace', 'path': ENTERPRISE + ':department', 'value': row['department']}, {'op': 'replace', 'path': 'displayName', 'value': row['displayName']}]}, cfg['SCIM_TOKEN'])
        else:
            request('http://localhost:8765/scim/v2/Users', 'POST', {'schemas': ['urn:ietf:params:scim:schemas:core:2.0:User', ENTERPRISE], 'externalId': row['employeeId'], 'userName': row['userName'], 'displayName': row['displayName'], 'active': active, ENTERPRISE: {'department': row['department']}}, cfg['SCIM_TOKEN'])
        endpoint = 'http://localhost:8080/admin/realms/aurora/users'
        found = request(endpoint + '?' + urllib.parse.urlencode({'username': row['userName'], 'exact': 'true'}), token=admin)
        if found and found[0].get('attributes', {}).get('employeeId') != [row['employeeId']]:
            raise ValueError('Conflito de employeeId no Keycloak; revisar antes de continuar')
        body = {'username': row['userName'], 'enabled': active, 'firstName': row['displayName'], 'lastName': 'Lab', 'email': row['userName'] + '@example.test', 'emailVerified': True, 'attributes': {'employeeId': [row['employeeId']], 'department': [row['department']]}}
        if found:
            request(endpoint + '/' + found[0]['id'], 'PUT', body, admin)
            if not active:
                request(endpoint + '/' + found[0]['id'] + '/logout', 'POST', token=admin)
        else:
            body['credentials'] = [{'type': 'password', 'value': cfg['STUDENT_PASSWORD'], 'temporary': False}]
            request(endpoint, 'POST', body, admin)
    print('Concluído. Reexecutar reconcilia estado; confira ambos os destinos. Falha parcial: corrija a causa e repita o mesmo CSV.')

if __name__ == '__main__':
    try:
        run()
    except (ValueError, OSError, urllib.error.URLError, KeyError) as error:
        raise SystemExit('Provisionamento interrompido; destinos podem estar parcialmente atualizados. ' + str(error))
