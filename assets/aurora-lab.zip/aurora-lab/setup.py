"""Gera segredos locais e um realm Keycloak, sem iniciar serviços ou cobrar recursos."""
import json
import secrets
from pathlib import Path

root = Path(__file__).resolve().parent
path = root / '.env'
if not path.exists():
    path.write_text('\n'.join(['ISSUER=http://localhost:8080/realms/aurora', 'SCIM_TOKEN=' + secrets.token_urlsafe(32), 'KC_ADMIN_PASSWORD=' + secrets.token_urlsafe(24), 'STUDENT_PASSWORD=' + secrets.token_urlsafe(18)]) + '\n')
    path.chmod(0o600)
cfg = dict(line.split('=', 1) for line in path.read_text().splitlines() if '=' in line)
realm = {'realm': 'aurora', 'enabled': True, 'registrationAllowed': False, 'accessTokenLifespan': 300, 'sslRequired': 'none', 'clients': [{'clientId': 'aurora-web', 'enabled': True, 'publicClient': True, 'standardFlowEnabled': True, 'directAccessGrantsEnabled': False, 'redirectUris': ['http://localhost:8765/callback'], 'webOrigins': ['http://localhost:8765'], 'attributes': {'pkce.code.challenge.method': 'S256'}, 'protocolMappers': [{'name': 'aurora-api-audience', 'protocol': 'openid-connect', 'protocolMapper': 'oidc-audience-mapper', 'config': {'included.custom.audience': 'aurora-api', 'access.token.claim': 'true', 'id.token.claim': 'false'}}]}]}
realm['components'] = {'org.keycloak.userprofile.UserProfileProvider': [{'providerId': 'declarative-user-profile', 'config': {'kc.user.profile.config': [json.dumps({'unmanagedAttributePolicy': 'ADMIN_EDIT', 'attributes': [{'name': n, 'permissions': {'view': ['admin','user'], 'edit': ['admin']}} for n in ['username','email','firstName','lastName']]})]}}]}
(root / 'realm.json').write_text(json.dumps(realm, indent=2))
print('Configuração pronta. Senhas e token estão em .env, somente neste computador. Não publique esse arquivo.')
