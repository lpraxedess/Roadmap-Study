"""Aurora: aplicação e SCIM exclusivamente em loopback para estudo."""
import base64
import hashlib
import html
import json
import os
import re
import secrets
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from contextlib import contextmanager
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives import hashes

ROOT = Path(__file__).resolve().parent

def env():
    path = ROOT / '.env'
    if not path.exists():
        raise SystemExit('Execute python setup.py primeiro.')
    return dict(line.split('=', 1) for line in path.read_text().splitlines() if '=' in line and not line.startswith('#'))

CFG = env()
ISSUER = CFG['ISSUER']
CLIENT = 'aurora-web'
BASE = 'http://localhost:8765'
SCHEMA = 'urn:ietf:params:scim:schemas:core:2.0:User'
ENTERPRISE = 'urn:ietf:params:scim:schemas:extension:enterprise:2.0:User'
PATCH = 'urn:ietf:params:scim:api:messages:2.0:PatchOp'
DB = ROOT / 'aurora.sqlite'
SESSIONS, PENDING = {}, {}

@contextmanager
def database():
    db = sqlite3.connect(DB, timeout=10)
    db.row_factory = sqlite3.Row
    try:
        with db:
            yield db
    finally:
        db.close()

with database() as db:
    db.execute('CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, externalId TEXT UNIQUE NOT NULL, userName TEXT UNIQUE NOT NULL, displayName TEXT NOT NULL, active INTEGER NOT NULL, department TEXT NOT NULL)')

def log(event, **data):
    with (ROOT / 'events.jsonl').open('a') as out:
        out.write(json.dumps({'time': time.time(), 'event': event, **data}) + '\n')

def remote(url, data=None, headers=None):
    request = urllib.request.Request(url, data=data, headers=headers or {})
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.load(response)

def decode(value):
    return base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))

def verify(token, audience, nonce=None):
    # Only the configured issuer supplies keys; never follow a token's jku/x5u.
    head, body, signature = token.split('.')
    header = json.loads(decode(head))
    claims = json.loads(decode(body))
    if header.get('alg') != 'RS256' or claims.get('iss') != ISSUER:
        raise ValueError('algoritmo ou emissor inválido')
    keys = remote(ISSUER + '/protocol/openid-connect/certs')['keys']
    key = next(k for k in keys if k['kid'] == header.get('kid') and k['kty'] == 'RSA')
    public = rsa.RSAPublicNumbers(int.from_bytes(decode(key['e']), 'big'), int.from_bytes(decode(key['n']), 'big')).public_key()
    public.verify(decode(signature), (head + '.' + body).encode(), padding.PKCS1v15(), hashes.SHA256())
    audiences = claims.get('aud', [])
    if isinstance(audiences, str):
        audiences = [audiences]
    now = time.time()
    if audience not in audiences or not isinstance(claims.get('exp'), (int, float)) or claims['exp'] <= now or claims.get('nbf', 0) > now + 30:
        raise ValueError('audiência ou validade inválida')
    if not claims.get('sub') or (nonce is not None and claims.get('nonce') != nonce):
        raise ValueError('sujeito ou nonce inválido')
    return claims

def resource(row):
    return {'schemas': [SCHEMA, ENTERPRISE], 'id': row['id'], 'externalId': row['externalId'], 'userName': row['userName'], 'displayName': row['displayName'], 'active': bool(row['active']), ENTERPRISE: {'department': row['department']}, 'meta': {'resourceType': 'User', 'location': BASE + '/scim/v2/Users/' + row['id']}}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # URLs de callback e tokens não vão para stdout.

    def respond(self, status, data, content='application/json'):
        body = json.dumps(data).encode() if not isinstance(data, str) else data.encode()
        self.send_response(status)
        self.send_header('Content-Type', content + '; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'")
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def error(self, status, detail):
        self.respond(status, {'schemas': ['urn:ietf:params:scim:api:messages:2.0:Error'], 'status': str(status), 'detail': detail}, 'application/scim+json')

    def redirect(self, url, cookie=None):
        self.send_response(302)
        self.send_header('Location', url)
        self.send_header('Cache-Control', 'no-store')
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.end_headers()

    def cookie(self, name):
        try:
            c = SimpleCookie(self.headers.get('Cookie', ''))
            return c[name].value if name in c else ''
        except Exception:
            return ''

    def read_json(self):
        size = int(self.headers.get('Content-Length', 0))
        if size < 1 or size > 65536:
            raise ValueError('Corpo ausente ou maior que 64 KB')
        value = json.loads(self.rfile.read(size))
        if not isinstance(value, dict):
            raise ValueError('Esperado objeto JSON')
        return value

    def admin(self):
        current = env()
        return any(secrets.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + current[key]) for key in ['SCIM_TOKEN', 'SCIM_TOKEN_NEXT'] if current.get(key))

    def identity(self):
        auth = self.headers.get('Authorization', '')
        if auth.startswith('Bearer '):
            return verify(auth[7:], 'aurora-api')
        session = SESSIONS.get(self.cookie('aurora'), {})
        if session.get('expires', 0) <= time.time():
            raise ValueError('Sessão expirada')
        return verify(session['access'], 'aurora-api')

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path, query = parsed.path, urllib.parse.parse_qs(parsed.query)
        if path == '/health':
            return self.respond(200, {'status': 'ok', 'purpose': 'laboratório local'})
        if path.startswith('/scim/v2/'):
            if not self.admin():
                return self.error(401, 'Bearer SCIM inválido')
            if path == '/scim/v2/Users':
                sql, args = 'SELECT * FROM users', []
                if 'filter' in query:
                    match = re.fullmatch(r'(externalId|userName) eq "([^"\\]{1,100})"', query['filter'][0])
                    if not match:
                        return self.error(400, 'Filtro suportado: externalId eq "id" ou userName eq "nome"')
                    sql += ' WHERE ' + match[1] + ' = ?'
                    args.append(match[2])
                try:
                    start = max(1, int(query.get('startIndex', ['1'])[0]))
                    count = max(0, min(100, int(query.get('count', ['100'])[0])))
                except ValueError:
                    return self.error(400, 'Paginação inválida')
                with database() as db:
                    rows = db.execute(sql + ' ORDER BY id', args).fetchall()
                return self.respond(200, {'schemas': ['urn:ietf:params:scim:api:messages:2.0:ListResponse'], 'totalResults': len(rows), 'startIndex': start, 'itemsPerPage': len(rows[start-1:start-1+count]), 'Resources': [resource(r) for r in rows[start-1:start-1+count]]}, 'application/scim+json')
            if path.startswith('/scim/v2/Users/'):
                with database() as db:
                    row = db.execute('SELECT * FROM users WHERE id=?', (path.rsplit('/', 1)[1],)).fetchone()
                return self.respond(200, resource(row), 'application/scim+json') if row else self.error(404, 'Usuário não encontrado')
            return self.error(404, 'Recurso não implementado no subconjunto didático')
        if path == '/login':
            # Bind the request to this browser and expire pending transactions.
            for key in list(PENDING):
                if PENDING[key]['expires'] < time.time():
                    del PENDING[key]
            state, nonce, verifier, binding = [secrets.token_urlsafe(32) for _ in range(4)]
            PENDING[state] = {'nonce': nonce, 'verifier': verifier, 'binding': binding, 'expires': time.time() + 300}
            challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
            params = {'client_id': CLIENT, 'redirect_uri': BASE + '/callback', 'response_type': 'code', 'scope': 'openid profile', 'state': state, 'nonce': nonce, 'code_challenge': challenge, 'code_challenge_method': 'S256'}
            return self.redirect(ISSUER + '/protocol/openid-connect/auth?' + urllib.parse.urlencode(params), 'transaction=' + binding + '; HttpOnly; SameSite=Lax; Path=/; Max-Age=300')
        if path == '/callback':
            transaction = PENDING.pop(query.get('state', [''])[0], None)
            if not transaction or transaction['expires'] < time.time() or not secrets.compare_digest(transaction['binding'], self.cookie('transaction')):
                return self.respond(400, {'error': 'state inválido ou expirado'})
            try:
                payload = urllib.parse.urlencode({'grant_type': 'authorization_code', 'client_id': CLIENT, 'redirect_uri': BASE + '/callback', 'code': query.get('code', [''])[0], 'code_verifier': transaction['verifier']}).encode()
                tokens = remote(ISSUER + '/protocol/openid-connect/token', payload, {'Content-Type': 'application/x-www-form-urlencoded'})
                identity = verify(tokens['id_token'], CLIENT, transaction['nonce'])
                access = verify(tokens['access_token'], 'aurora-api')
                if identity['sub'] != access['sub']:
                    raise ValueError('Sujeitos diferentes')
                sid = secrets.token_urlsafe(32)
                SESSIONS[sid] = {'access': tokens['access_token'], 'expires': min(time.time()+600, access['exp'])}
                log('login', subject=identity['sub'])
                return self.redirect('/', 'aurora=' + sid + '; HttpOnly; SameSite=Lax; Path=/; Max-Age=600')
            except Exception:
                return self.respond(401, {'error': 'Falha na troca ou validação de tokens; confira emissor, cliente, callback, relógio e audience.'})
        if path in ['/api/financeiro', '/api/juridico']:
            try:
                claims = self.identity()
            except Exception:
                return self.respond(401, {'error': 'Autenticação ausente ou token inválido'})
            with database() as db:
                row = db.execute('SELECT * FROM users WHERE userName=?', (claims.get('preferred_username', ''),)).fetchone()
            expected = 'Financeiro' if path.endswith('financeiro') else 'Jurídico'
            allowed = bool(row and row['active'] and row['department'] == expected)
            log('access', subject=claims['sub'], resource=expected, allowed=allowed)
            return self.respond(200 if allowed else 403, {'decision': 'permitido' if allowed else 'negado', 'resource': expected, 'policy': 'conta ativa E departamento correspondente'})
        if path == '/':
            return self.respond(200, '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Aurora · laboratório IAM</title><style>body{background:#101114;color:#eee;font:18px/1.6 system-ui;max-width:720px;margin:8vh auto;padding:24px}a{color:#79d0ff}li{margin:15px 0}</style><h1>Aurora Lab</h1><p>Uma identidade. Dois departamentos. Acesso decidido no servidor.</p><ol><li><a href="/login">Entrar com Keycloak (Code + PKCE)</a></li><li><a href="/api/financeiro">Testar acesso ao Financeiro</a></li><li><a href="/api/juridico">Testar acesso ao Jurídico</a></li></ol><p>200: permitido · 401: autenticação inválida · 403: permissão negada.</p><p>A aplicação reconsulta o cadastro SCIM a cada acesso. Desativar no destino bloqueia mesmo uma sessão local ainda existente.</p><form method="post" action="/logout"><button>Sair da aplicação</button></form><p>Ambiente didático local. Logout da aplicação não encerra automaticamente a sessão do IdP.</p></html>', 'text/html')
        self.respond(404, {'error': 'Não encontrado'})

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == '/logout':
            if self.headers.get('Origin') != BASE:
                return self.respond(403, {'error': 'Origem inválida'})
            SESSIONS.pop(self.cookie('aurora'), None)
            return self.redirect('/', 'aurora=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0')
        if path != '/scim/v2/Users':
            return self.error(404, 'Recurso desconhecido')
        if not self.admin():
            return self.error(401, 'Bearer SCIM inválido')
        try:
            data = self.read_json()
            if SCHEMA not in data.get('schemas', []) or not all(isinstance(data.get(k), str) and 0 < len(data[k]) <= 100 for k in ['externalId', 'userName', 'displayName']) or not isinstance(data.get('active', True), bool):
                raise ValueError('Schemas, identificador ou atributos inválidos')
            department = data.get(ENTERPRISE, {}).get('department', '')
            if department not in ['', 'Financeiro', 'Jurídico', 'TI']:
                raise ValueError('Departamento inválido')
            uid = secrets.token_hex(12)
            with database() as db:
                db.execute('INSERT INTO users VALUES (?,?,?,?,?,?)', (uid, data['externalId'], data['userName'], data['displayName'], int(data.get('active', True)), department))
                row = db.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
            log('scim.create', id=uid, externalId=data['externalId'])
            self.respond(201, resource(row), 'application/scim+json')
        except sqlite3.IntegrityError:
            self.error(409, 'externalId ou userName já existe')
        except (ValueError, TypeError, AttributeError):
            self.error(400, 'Documento SCIM inválido')

    def do_PATCH(self):
        if not self.admin():
            return self.error(401, 'Bearer SCIM inválido')
        path = urllib.parse.urlparse(self.path).path
        if not path.startswith('/scim/v2/Users/'):
            return self.error(404, 'Recurso desconhecido')
        uid = path.rsplit('/', 1)[1]
        try:
            data = self.read_json()
            if data.get('schemas') != [PATCH] or not isinstance(data.get('Operations'), list) or not 0 < len(data['Operations']) <= 10:
                raise ValueError('PatchOp inválido')
            with database() as db:
                if not db.execute('SELECT id FROM users WHERE id=?', (uid,)).fetchone():
                    return self.error(404, 'Usuário não encontrado')
                for operation in data['Operations']:
                    field, value = operation.get('path'), operation.get('value')
                    if operation.get('op', '').lower() != 'replace':
                        raise ValueError('Este lab implementa replace, não todo SCIM')
                    if field == 'active' and isinstance(value, bool):
                        column, value = 'active', int(value)
                    elif field == ENTERPRISE + ':department' and value in ['Financeiro', 'Jurídico', 'TI', '']:
                        column = 'department'
                    elif field in ['displayName', 'userName'] and isinstance(value, str) and 0 < len(value) <= 100:
                        column = field
                    else:
                        raise ValueError('Atributo ou valor inválido')
                    db.execute('UPDATE users SET ' + column + '=? WHERE id=?', (value, uid))
                row = db.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
            log('scim.patch', id=uid)
            self.respond(200, resource(row), 'application/scim+json')
        except sqlite3.IntegrityError:
            self.error(409, 'Conflito de identidade')
        except (ValueError, TypeError, AttributeError):
            self.error(400, 'Patch inválido; use schemas PatchOp e paths suportados')

if __name__ == '__main__':
    print('Aurora em http://localhost:8765 · SCIM exige token de .env · Ctrl+C encerra')
    ThreadingHTTPServer(('127.0.0.1', 8765), Handler).serve_forever()
