"""Backup consistente do banco da aplicação. Não inclui o banco do Keycloak."""
import argparse
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('action', choices=['save', 'restore'])
p.add_argument('file')
a = p.parse_args()
source = root / 'aurora.sqlite' if a.action == 'save' else Path(a.file)
target = Path(a.file) if a.action == 'save' else root / 'aurora.sqlite'
if not source.exists() or source.resolve() == target.resolve():
    raise SystemExit('Origem ausente ou destino igual à origem')
if target.exists() and input('Substituir destino? Digite RESTAURAR: ') != 'RESTAURAR':
    raise SystemExit('Cancelado')
with sqlite3.connect(source) as src, sqlite3.connect(target) as dst:
    src.backup(dst)
print('Concluído. Reinicie o servidor se restaurou o banco e valide os acessos.')
